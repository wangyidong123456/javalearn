package com.igeek.solr.cloud;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.CloudSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.SolrParams;

public class Main {

	public static void main(String[] args) throws Exception {
		//创建zookeeper的host字符串
		String zkHost = "192.168.8.129:2181,192.168.8.130:2181,192.168.8.131:2181";
		//要使用SolrJ操作SolrCloud需要创建Server对象
		CloudSolrServer server = new CloudSolrServer(zkHost);

		//设置索引库的名称
		String collection = "core";
		//指定操作的索引库的core
		server.setDefaultCollection(collection);

		//准备更行的数据
		List<String> title = new ArrayList<String>();
		title.add("这是我们更新的数据");
		Bean bean = new Bean("1", title);
		
		//执行更新的操作
		server.addBean(bean);
		
		//提交操作
		server.commit();
		
		
	}

}
