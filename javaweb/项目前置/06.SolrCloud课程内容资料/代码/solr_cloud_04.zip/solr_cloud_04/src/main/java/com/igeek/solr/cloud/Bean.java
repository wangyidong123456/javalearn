package com.igeek.solr.cloud;

import java.util.List;

import org.apache.solr.client.solrj.beans.Field;

public class Bean {
	@Field("id")
	private String id;
	@Field("title")
	private List<String> title;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<String> getTitle() {
		return title;
	}
	public void setTitle(List<String> title) {
		this.title = title;
	}
	public Bean(String id, List<String> title) {
		super();
		this.id = id;
		this.title = title;
	}
	public Bean() {
		super();
	}
	@Override
	public String toString() {
		return "Bean [id=" + id + ", title=" + title + "]";
	}
	
}
