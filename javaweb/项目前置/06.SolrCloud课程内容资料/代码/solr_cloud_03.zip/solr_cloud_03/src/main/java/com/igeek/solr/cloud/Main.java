package com.igeek.solr.cloud;

import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.CloudSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.SolrParams;

public class Main {

	public static void main(String[] args) throws Exception {
		//创建zookeeper的host字符串
		String zkHost = "192.168.8.129:2181,192.168.8.130:2181,192.168.8.131:2181";
		//要使用SolrJ操作SolrCloud需要创建Server对象
		CloudSolrServer server = new CloudSolrServer(zkHost);

		//设置索引库的名称
		String collection = "core";
		//指定操作的索引库的core
		server.setDefaultCollection(collection);

		//设置查询条件
		SolrQuery params = new SolrQuery("title:Hello");
		
		//设置高亮
		params.setHighlightSimplePre("<em>");
		params.setHighlightSimplePost("</em>");
		params.addHighlightField("title");
		
		//进行查询操作
		QueryResponse queryResponse = server.query(params);
		
		SolrDocumentList results = queryResponse.getResults();
		Map<String, Map<String, List<String>>> highlighting = queryResponse.getHighlighting();
		
		for (SolrDocument solrDocument : results) {
			String title = highlighting.get(solrDocument.get("id")).get("title").get(0);
			System.out.println(title);
		}
	}

}
