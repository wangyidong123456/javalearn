package com.igeek.solr.cloud;

import org.apache.solr.client.solrj.beans.Field;

public class Book {
	@Field("id")
	private String id;
	@Field("name")
	private String name;
	@Field("price")
	private float price;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Book(String id, String name, float price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	public Book() {
		super();
	}
	
	
}
