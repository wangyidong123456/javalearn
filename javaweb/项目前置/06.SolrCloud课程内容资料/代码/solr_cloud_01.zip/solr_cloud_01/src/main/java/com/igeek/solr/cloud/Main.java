package com.igeek.solr.cloud;

import org.apache.solr.client.solrj.impl.CloudSolrServer;
import org.apache.solr.common.SolrInputDocument;

public class Main {

	public static void main(String[] args) throws Exception {
		//创建zookeeper的host字符串
		String zkHost = "192.168.8.129:2181,192.168.8.130:2181,192.168.8.131:2181";
		//要使用SolrJ操作SolrCloud需要创建Server对象
		CloudSolrServer server = new CloudSolrServer(zkHost);

		//设置索引库的名称
		String collection = "core";
		//指定操作的索引库的core
		server.setDefaultCollection(collection);
		
		//创建doc对象
		SolrInputDocument doc = new SolrInputDocument();
		//插入字段
		doc.addField("id", "10");
		doc.addField("title", "使用SolrJ插入的数据");
		
		//进行索引的创建
		server.add(doc);
		
		//提交
		server.commit();
		
		System.out.println("索引创建完毕");
	}

}
