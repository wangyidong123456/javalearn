package com.igeek.solr;

import java.util.ArrayList;
import java.util.List;

import org.apache.solr.client.solrj.impl.HttpSolrServer;

public class Main2 {

	public static void main(String[] args) throws Exception {
		//定义Solr的URL路径
		String baseURL = "http://localhost:8889/solr/core1";
		//要使用SolrJ首先创建服务对象，Solr实际上是提供web服务，需啊哟创建web服务的对象，支持HTTP请求
		HttpSolrServer server = new HttpSolrServer(baseURL);
		
		//Solr提供的是web服务，在接收用户传递的参数是就是request参数
		String query="description:典籍";
		
		//删除索引
		server.deleteByQuery(query);
		
		//提交请求
		server.commit();
		
	}

}
