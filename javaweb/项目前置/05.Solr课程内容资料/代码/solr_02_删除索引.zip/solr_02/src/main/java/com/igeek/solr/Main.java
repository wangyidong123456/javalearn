package com.igeek.solr;

import java.util.ArrayList;
import java.util.List;

import org.apache.solr.client.solrj.impl.HttpSolrServer;

public class Main {

	public static void main(String[] args) throws Exception {
		//定义Solr的URL路径
		String baseURL = "http://localhost:8889/solr/core1";
		//要使用SolrJ首先创建服务对象，Solr实际上是提供web服务，需啊哟创建web服务的对象，支持HTTP请求
		HttpSolrServer server = new HttpSolrServer(baseURL);
		
		List<String> list = new ArrayList<String>();
		list.add("10");
		list.add("12");
		//删除索引
		server.deleteById(list);
		
		//提交请求
		server.commit();
		
	}

}
