package com.igeek.solr;

import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.UpdateResponse;

import com.igeek.domain.Person;

public class Main2 {

	public static void main(String[] args) throws Exception {
		//创建Java对象
		Person person = new Person("12", "zhangsan");
		
		//创建Server
		String baseURL = "http://localhost:8889/solr/core1";
		HttpSolrServer httpSolrServer = new HttpSolrServer(baseURL);
		
		//将对象插入索引库
		UpdateResponse updateResponse = httpSolrServer.addBean(person);
		int status = updateResponse.getStatus();
		System.out.println(status);
		//提交
		httpSolrServer.commit();
	}

}
