package com.igeek.solr;

import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.UpdateResponse;

import com.igeek.domain.Book;
import com.igeek.domain.Person;

public class Main3 {

	public static void main(String[] args) throws Exception {
		//创建Java对象
		Book book = new Book("13", "Java从入门到精通","abc","这是一本好书");
		
		//创建Server
		String baseURL = "http://localhost:8889/solr/core1";
		HttpSolrServer httpSolrServer = new HttpSolrServer(baseURL);
		
		//将对象插入索引库
		UpdateResponse updateResponse = httpSolrServer.addBean(book);
		int status = updateResponse.getStatus();
		System.out.println(status);
		//提交
		httpSolrServer.commit();
	}

}
