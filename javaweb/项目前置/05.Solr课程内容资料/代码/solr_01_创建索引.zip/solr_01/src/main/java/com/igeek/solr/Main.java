package com.igeek.solr;

import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.common.SolrInputDocument;

public class Main {

	public static void main(String[] args) throws Exception {
		//定义Solr的URL路径
		String baseURL = "http://localhost:8889/solr/core1";
		//要使用SolrJ首先创建服务对象，Solr实际上是提供web服务，需啊哟创建web服务的对象，支持HTTP请求
		HttpSolrServer server = new HttpSolrServer(baseURL);
		
		//添加索引，需要Document对象
		SolrInputDocument document = new SolrInputDocument();
		document.addField("id", "10");
		document.addField("title", "今天星期二，是一周的第三天。");
		
		//将Document添加到索引库
		server.add(document);
		
		//提交请求
		server.commit();
		
	}

}
