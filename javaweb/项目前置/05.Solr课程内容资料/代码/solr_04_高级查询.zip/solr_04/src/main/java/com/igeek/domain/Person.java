package com.igeek.domain;

import org.apache.solr.client.solrj.beans.Field;

/**
 * 需要使用Field标记属性对应的Solr中的Field的名称
 * @author cp
 */
public class Person {
	
	@Field("id")
	private String id;
	@Field("name")
	private String name;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Person(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Person() {
		super();
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + "]";
	}
	
}
