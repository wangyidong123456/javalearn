package com.igeek.solr;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.SolrParams;

public class Main2 {

	public static void main(String[] args) throws Exception {
		//定义Solr的URL路径
		String baseURL = "http://localhost:8889/solr/core1";
		//要使用SolrJ首先创建服务对象，Solr实际上是提供web服务，需啊哟创建web服务的对象，支持HTTP请求
		HttpSolrServer server = new HttpSolrServer(baseURL);
		
		SolrParams params = new SolrQuery("title:app~");
		QueryResponse queryResponse = server.query(params);
		
		SolrDocumentList results = queryResponse.getResults();
		
		for (SolrDocument solrDocument : results) {
			System.out.println(solrDocument.get("title"));
		}
		
		//提交请求
		server.commit();
		
	}

}
