package com.igeek.domain;

import org.apache.solr.client.solrj.beans.Field;

public class Book {
	@Field("id")
	private String id;
	@Field("author")
	private String author;
	@Field("name")
	private String name;
	@Field("description")
	private String context;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	public Book(String id, String author, String name, String context) {
		super();
		this.id = id;
		this.author = author;
		this.name = name;
		this.context = context;
	}
	public Book() {
		super();
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", author=" + author + ", name=" + name + ", context=" + context + "]";
	}
	
	
}
