package com.igeek.solr;

import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrQuery.ORDER;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.SolrParams;

import com.igeek.domain.Book;

public class Main {

	public static void main(String[] args) throws Exception {
		//定义Solr的URL路径
		String baseURL = "http://localhost:8889/solr/core1";
		//要使用SolrJ首先创建服务对象，Solr实际上是提供web服务，需啊哟创建web服务的对象，支持HTTP请求
		HttpSolrServer server = new HttpSolrServer(baseURL);
		
		String query = "name:论语";
		
		//进行查询操作
		SolrQuery params = new SolrQuery(query);
		
		//设置高亮
		params.setHighlightSimplePre("<em>");
		params.setHighlightSimplePost("</em>");
		//设置高亮显示的字段
		params.addHighlightField("description");
		params.addHighlightField("name");
		
		QueryResponse queryResponse = server.query(params);
		SolrDocumentList results = queryResponse.getResults();
		
		
		//在map中首先使用每一条数据的id作为键，将数据作为值（只有高亮字段）
		//Map<String, List<String>>存放的是一条数据的所有高亮字段，键就是字段的名称，值就是高亮显示的数据
		//List<String>里面就是经过处理的高亮的内容，主要是因为Solr中的字段可以存储多个值，对于单个数据而言，list的长度都为1
		Map<String, Map<String, List<String>>> highlighting = queryResponse.getHighlighting();
		
		//那么获取高亮数据可以获取对应的id，在指定高亮字段的名称，在获取list的第0个元素
		for (SolrDocument solrDocument : results) {
			String id = (String) solrDocument.get("id");
			String name = highlighting.get(id).get("name").get(0);
			String description = highlighting.get(id).get("description").get(0);
			
			System.out.println("id:"+id+"--- name:"+name+"---description:"+description);
		}
		
		//提交请求
		server.commit();
		
	}

}
