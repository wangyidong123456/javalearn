package com.igeek.lucene;

import java.io.File;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

/**
 * 使用Fuzzy支持模糊查询
 * @author cp
 *
 */
public class Lucene_05 {

	public static void main(String[] args) throws Exception {
		//创建Directory对象用来指定索引文件存放的位置
		Directory directory = FSDirectory.open(new File("Indexs"));
		
		//进行检索需要首先读取文件，需要创建IndexReader
		@SuppressWarnings("deprecation")
		IndexReader reader = IndexReader.open(directory);
		
		//需要搜索功能使用IndexSearch
		IndexSearcher searcher = new IndexSearcher(reader);
		
		//创建Term，Term中的内容是不能分词的最小单位
		Term term = new Term("title", "情人");
		//使用Term进行查询
		Query query = new FuzzyQuery(term);
		
		//调用searcher的search方法进行检索,n表示查询到的记录的条数
		TopDocs topDocs = searcher.search(query, 10);
		
		//获取ScoreDoc对象，存在文档的ID
		ScoreDoc[] scoreDocs = topDocs.scoreDocs;
		for (ScoreDoc scoreDoc : scoreDocs) {
			//获取文档的ID
			int doc = scoreDoc.doc;
			//获取Document对象
			Document document = searcher.doc(doc);
			//获取文档中的数据
			String id = document.get("id");
			String title = document.get("title");
			System.out.println(id+":"+title);
		}
	}
}
