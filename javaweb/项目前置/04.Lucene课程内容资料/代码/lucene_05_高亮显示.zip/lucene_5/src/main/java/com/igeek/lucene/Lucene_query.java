package com.igeek.lucene;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Formatter;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.Scorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class Lucene_query {
	public static void main(String[] args) throws Exception {
		Directory directory = FSDirectory.open(new File("indexes"));
		IndexReader reader = IndexReader.open(directory);
		
		IndexSearcher searcher = new IndexSearcher(reader);
		
		Analyzer a = new IKAnalyzer();
		QueryParser parser = new QueryParser("title", a );
		Query query = parser.parse("大白");
		TopDocs topDocs = searcher.search(query, 10);
		
		//用来设置关键字高亮显示的格式化的方式
		Formatter formatter = new SimpleHTMLFormatter("<em style='font=red'>", "</em>");
		Scorer fragmentScorer = new QueryScorer(query);
		//设置高亮显示
		Highlighter highlighter = new Highlighter(formatter, fragmentScorer);
		
		ScoreDoc[] scoreDocs = topDocs.scoreDocs;
		for (ScoreDoc scoreDoc : scoreDocs) {
			Document document = searcher.doc(scoreDoc.doc);
			
			String id = document.get("id");
			String title = document.get("title");
			
			//使用高亮highlighter处理title中的关键字
			String titleWithHighLight = highlighter.getBestFragment(a, "title", title);
			
			System.out.println(id+"："+title);
			System.out.println(id+":"+titleWithHighLight);
		}
		
		reader.close();
	}
}
