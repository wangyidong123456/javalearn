package com.igeek.lucene;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.IntField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class Lucene_01 {

	public static void main(String[] args) throws Exception {
		// 表示存放索引库的位置
		Directory directory = FSDirectory.open(new File("indexes"));

		// 当期使用的Lucene的版本号,可以从Version中获取
		Version matchVersion = Version.LATEST;

		// 表示分析器，实际上就是分词器
		Analyzer analyzer = new IKAnalyzer();

		// 设置IndexWriter的配置对象
		IndexWriterConfig config = new IndexWriterConfig(matchVersion, analyzer);

		// 创建索引，将索引写入磁盘，需要是使用writer
		IndexWriter writer = new IndexWriter(directory, config);

		addDocument(writer);
		
		// 关闭资源
		writer.close();

		System.out.println("索引创建成功");
	}

	private static void addDocument(IndexWriter writer) throws Exception {
		// 创建文档对象，也就是说在Lucene的索引库的实际上存放的是一个一个的类文档形式
		Document doc = new Document();

		Random random = new Random();
		// 创建Filed需要制定字段的名称，字段的内容，还需要设置是否需要存储
		IndexableField fieldId = new IntField("id", 1, Store.YES);
		TextField fieldTitle = new TextField("title", "十九大提出了很多民生问题", Store.YES);
		fieldTitle.setBoost(2.0f);
		IndexableField fieldHits = new IntField("hits", random.nextInt(1000), Store.YES);

		// 向document中添加字段
		doc.add(fieldTitle);
		doc.add(fieldId);
		doc.add(fieldHits);

		// 调用IndexWriter的addDocument方法完成创建索引的操作
		writer.addDocument(doc);

		// 提交
		writer.commit();
	}

}
