package com.igeek.lucene;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.IntField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class Lucene_update {
	public static void main(String[] args) throws Exception {
		//更新实际上是写入的操作，需要使用Writer
		Directory d = FSDirectory.open(new File("indexes"));
		IndexWriterConfig conf = new IndexWriterConfig(Version.LATEST, new IKAnalyzer());
		IndexWriter writer = new IndexWriter(d, conf);
		
		//查询的条件
		Term term = new Term("title", "iphone");
		//定义更新数据
		Document doc = new Document();
		doc.add(new IntField("id", 1, Store.YES));
		doc.add(new TextField("title", "逝去的2017手机江湖：洗牌与逆袭、苟且与远方",Store.YES));
		
		//进行更新操作
		writer.updateDocument(term, doc);
		
		//提交
		writer.commit();
		
		//关闭资源
		writer.close();
	}
}
