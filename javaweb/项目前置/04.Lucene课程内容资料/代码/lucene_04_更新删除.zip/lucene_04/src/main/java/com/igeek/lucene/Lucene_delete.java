package com.igeek.lucene;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.IntField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class Lucene_delete {
	public static void main(String[] args) throws Exception {
		//删除实际上是写入的操作，需要使用Writer
		Directory d = FSDirectory.open(new File("indexes"));
		IndexWriterConfig conf = new IndexWriterConfig(Version.LATEST, new IKAnalyzer());
		IndexWriter writer = new IndexWriter(d, conf);
		
		/*Analyzer a = new  IKAnalyzer();
		QueryParser parser = new QueryParser("title", a);
		Query query = parser.parse("iphone");
		
		//执行删除操作
		writer.deleteDocuments(query);*/
		
		//删除所有索引
		writer.deleteAll();
		
		//提交
		writer.commit();
		
		//关闭资源
		writer.close();
	}
}
