package com.igeek.lucene;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Formatter;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.Scorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class Lucene_query {
	public static void main(String[] args) throws Exception {
		Directory directory = FSDirectory.open(new File("indexes"));
		IndexReader reader = IndexReader.open(directory);

		IndexSearcher searcher = new IndexSearcher(reader);

		// 设置分页的数据
		int page = 2;
		int nums = 20;
		int min = nums * (page - 1);
		int max = nums * page;

		Analyzer a = new IKAnalyzer();
		QueryParser parser = new QueryParser("title", a);
		Query query = parser.parse("title");
		TopDocs topDocs = searcher.search(query, max);

		ScoreDoc[] scoreDocs = topDocs.scoreDocs;
		
		//设置当前的查询应该从指定的最小值位置开始显示
		for (int i = min ; i < scoreDocs.length ; i++) {
			Document document = searcher.doc(scoreDocs[i].doc);

			String id = document.get("id");
			String title = document.get("title");

			System.out.println(id + "：" + title);
		}

		reader.close();
	}
}
