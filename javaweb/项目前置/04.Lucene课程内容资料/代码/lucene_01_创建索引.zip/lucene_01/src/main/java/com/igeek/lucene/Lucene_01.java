package com.igeek.lucene;

import java.io.File;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class Lucene_01 {

	public static void main(String[] args) throws Exception {
		//表示存放索引库的位置
		Directory directory = FSDirectory.open(new File("Indexs"));
		
		//当期使用的Lucene的版本号,可以从Version中获取
		Version matchVersion = Version.LATEST;
		
		//表示分析器，实际上就是分词器
		Analyzer analyzer = new IKAnalyzer();
		
		//设置IndexWriter的配置对象
		IndexWriterConfig config = new IndexWriterConfig(matchVersion, analyzer);
		
		//创建索引，将索引写入磁盘，需要是使用writer
		IndexWriter writer = new IndexWriter(directory, config);

		//创建文档对象，也就是说在Lucene的索引库的实际上存放的是一个一个的类文档形式
		Document doc = new Document();
		
		//创建Filed需要制定字段的名称，字段的内容，还需要设置是否需要存储
		IndexableField fieldTitle = new TextField("title", "习近平引领加快建设创新型国家",Store.YES);
		IndexableField fieldUrl = new StringField("url", "http://news.cctv.com/2018/01/08/ARTI8o52qDVusOyB343izRMe180108.shtml", Store.YES);
		IndexableField fieldText = new TextField("text","习近平总书记在党的十九大报告中指出，“加快建设创新型国家”。目前，我国已成为全球第二大研发投入大国，接近世界创新国家的第一集团，正坚定实施创新驱动发展战略，强化创新第一动力的地位和作用，以科技创新引领全面创新。十九大以来，总书记在多个重要场合和会议中都强调重视科技创新，央视网特梳理以飨读者", Store.NO);
		
		//向document中添加字段
		doc.add(fieldTitle);
		doc.add(fieldUrl);
		doc.add(fieldText);
		
		//调用IndexWriter的addDocument方法完成创建索引的操作
		writer.addDocument(doc);
		
		//提交
		writer.commit();
		
		//关闭资源
		writer.close();
		
		System.out.println("索引创建成功");
	}

}
