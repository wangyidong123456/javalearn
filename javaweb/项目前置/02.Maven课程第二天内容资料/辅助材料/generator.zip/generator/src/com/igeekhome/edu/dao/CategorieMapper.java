package com.igeekhome.edu.dao;

import com.igeekhome.edu.model.Categorie;
import com.igeekhome.edu.model.CategorieExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CategorieMapper {
    int countByExample(CategorieExample example);

    int deleteByExample(CategorieExample example);

    int deleteByPrimaryKey(Integer categorieId);

    int insert(Categorie record);

    int insertSelective(Categorie record);

    List<Categorie> selectByExample(CategorieExample example);

    Categorie selectByPrimaryKey(Integer categorieId);

    int updateByExampleSelective(@Param("record") Categorie record, @Param("example") CategorieExample example);

    int updateByExample(@Param("record") Categorie record, @Param("example") CategorieExample example);

    int updateByPrimaryKeySelective(Categorie record);

    int updateByPrimaryKey(Categorie record);
}