package com.igeekhome.edu.model;

import java.util.Date;

public class Note {
    private Integer noteId;

    private String noteName;

    private Date createtime;

    private Integer category;

    private Integer author;

    private Integer isdel;

    private byte[] noteContent;

    public Integer getNoteId() {
        return noteId;
    }

    public void setNoteId(Integer noteId) {
        this.noteId = noteId;
    }

    public String getNoteName() {
        return noteName;
    }

    public void setNoteName(String noteName) {
        this.noteName = noteName == null ? null : noteName.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public Integer getAuthor() {
        return author;
    }

    public void setAuthor(Integer author) {
        this.author = author;
    }

    public Integer getIsdel() {
        return isdel;
    }

    public void setIsdel(Integer isdel) {
        this.isdel = isdel;
    }

    public byte[] getNoteContent() {
        return noteContent;
    }

    public void setNoteContent(byte[] noteContent) {
        this.noteContent = noteContent;
    }
}