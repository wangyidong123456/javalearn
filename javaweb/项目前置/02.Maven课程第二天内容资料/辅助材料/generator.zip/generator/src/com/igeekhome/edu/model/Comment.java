package com.igeekhome.edu.model;

import java.util.Date;

public class Comment {
    private Integer commentId;

    private Date createtime;

    private Integer isdel;

    private byte[] commentContent;

    public Integer getCommentId() {
        return commentId;
    }

    public void setCommentId(Integer commentId) {
        this.commentId = commentId;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Integer getIsdel() {
        return isdel;
    }

    public void setIsdel(Integer isdel) {
        this.isdel = isdel;
    }

    public byte[] getCommentContent() {
        return commentContent;
    }

    public void setCommentContent(byte[] commentContent) {
        this.commentContent = commentContent;
    }
}