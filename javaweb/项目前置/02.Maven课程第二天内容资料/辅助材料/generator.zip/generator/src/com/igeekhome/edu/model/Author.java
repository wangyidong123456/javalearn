package com.igeekhome.edu.model;

import java.util.Date;

public class Author {
    private Integer authorId;

    private String authorName;

    private Date createtime;

    private Integer isdel;

    private byte[] authorComment;

    public Integer getAuthorId() {
        return authorId;
    }

    public void setAuthorId(Integer authorId) {
        this.authorId = authorId;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName == null ? null : authorName.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Integer getIsdel() {
        return isdel;
    }

    public void setIsdel(Integer isdel) {
        this.isdel = isdel;
    }

    public byte[] getAuthorComment() {
        return authorComment;
    }

    public void setAuthorComment(byte[] authorComment) {
        this.authorComment = authorComment;
    }
}